import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions } from '@angular/http';
import 'rxjs/add/operator/map';

const API_URL = 'https://www.salesone.biz/rest/V1/barcodesearch/';
/*
  Generated class for the ProductService provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular 2 DI.
*/
@Injectable()
export class ProductService {
  public data: any;
  public response: any;
  public orders: any;
  public orderDetails: any;

  constructor(public http: Http) {
    console.log('Hello ProductService Provider');
  }

  load(barcode) {
    let headers = new Headers({
      'Access-Control-Allow-Origin' : '*'
    });
    return this.http.get(API_URL + "search/" + barcode, headers)
    .map(res => res.json());
  }

  loadItem(itemcode) {
    let headers = new Headers({
      'Access-Control-Allow-Origin' : '*'
    });

    return this.http.get(API_URL + "searchitembycode/" + itemcode, headers)
    .map(res => res.json());
  }

  submitOrder(data){
    if (this.response) {
      return Promise.resolve(this.response);
    }

    return new Promise(resolve => {
  		let options = new RequestOptions({
  			params: data
  		});

      this.http.get(API_URL + 'save/', options)
        .map(res  => res.json())
        .subscribe(data => {
          this.response = data;
          resolve(this.response);
        });
    });
  }

  updateOrder(data){
    if (this.response) {
      return Promise.resolve(this.response);
    }

    return new Promise(resolve => {
  		let options = new RequestOptions({
  			params: data
  		});

      this.http.get(API_URL + 'update/', options)
        .map(res  => res.json())
        .subscribe(data => {
          this.response = data;
          resolve(this.response);
        });
    });
  }

  getOrders(){
    if (this.orders) {
      return Promise.resolve(this.orders);
    }

    // don't have the data yet
    return new Promise(resolve => {
      let headers = new Headers({
        'Access-Control-Allow-Origin' : '*'
      });

      this.http.get(API_URL + 'getorders/', headers)
        .map(res => res.json())
        .subscribe(data => {
          this.orders = data;
          resolve(this.orders);
        });
    });
  }
  getOrderDetails(order_id){
    if (this.orderDetails) {
      return Promise.resolve(this.orderDetails);
    }

    // don't have the data yet
    return new Promise(resolve => {
      let headers = new Headers({
        'Access-Control-Allow-Origin' : '*'
      });

      this.http.get(API_URL + 'getorderdetails/' + order_id, headers)
        .map(res => res.json())
        .subscribe(data => {
          this.orderDetails = data;
          resolve(this.orderDetails);
        });
    });
  }

  logError(error){
    let options = new RequestOptions({
      params: {
        error: error
      }
    });

    this.http.get(API_URL + 'logerror/', options)
      .map(res  => res.json())
      .subscribe(data => {
        if(data){
          alert("Sorry for the inconvenience, we've log the error for investigation. Thank you!");
        }
      });
  }

  export(){
    let headers = new Headers({
      'Access-Control-Allow-Origin' : '*'
    });
    return this.http.get(API_URL + "export/", headers)
    .map(res => res.json());
  }
}
