import { Component, ElementRef } from '@angular/core';
import { ViewController, NavParams, Events } from 'ionic-angular';

//pop-up page
@Component({
  selector: 'page-popup',
  templateUrl: 'popover.html'
})
export class PopoverPage{
  private rowNumber = 0;
  private page = "";

  constructor(public viewCtrl: ViewController, private navParams: NavParams, private el: ElementRef, private events: Events) {
    this.rowNumber = this.navParams.data.row;
    this.page = this.navParams.data.page;
  }

  close() {
    this.viewCtrl.dismiss();
  }

  editItem(row){
    let qty: any;
    qty = parseInt(prompt("Enter qty: ",'1'));
    qty = isNaN(qty) ? 1 : qty;
    this.events.publish('row:edited',row,qty,this.page);
    this.close();
  }

  deleteItem(row){
    if(confirm("Are you sure?")){
      this.events.publish('row:deleted',row,this.page);
      this.close();
    }
  }
}
