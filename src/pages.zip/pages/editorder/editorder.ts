import { Component } from '@angular/core';
import { NavController, NavParams, Events, PopoverController } from 'ionic-angular';
import { BarcodeScanner } from '@ionic-native/barcode-scanner';
import { CustomerInfoPage } from '../customerinfo/customerinfo';
import { PopoverPage } from '../popover/popover';
import { SQLite } from '@ionic-native/sqlite';
import { SqliteService } from '../../providers/sqlite-service';

//navigation page
@Component({
  selector: 'page-editorder',
  templateUrl: '../home/home.html',
  providers: [SqliteService]
})
export class EditOrderPage{
  private orderData: any = [];
  public product = [];
  public rowNumber = 0;
  private index = 0;
  private grand_total = 0;
  private totDiscount: any = 0;
  private hasOrder = false;
  private totQty = 0;
  private defaultDiscount = 0;
  private discountedOrder = false;
  private customer_info = [];
  private title = "";
  private save;

  constructor(private navCtrl: NavController, private params: NavParams, private events: Events, public popoverCtrl: PopoverController, private barcodeScanner: BarcodeScanner, private sqlite: SQLite, private sqlService: SqliteService){
    this.title = "Edit Order #";
    this.save = false;

    this.orderData = this.params.data.order_data;

    //set customer info
    this.events.subscribe('info:inputted', (info)  => {
      this.customer_info = info;
    });

    this.events.subscribe('row:edited', (row,qty,page)  => {
      if(page == "edit"){
        this.edit(row,qty,page);
      }
    });

    this.events.subscribe('row:deleted', (row,page)  => {
      if(page == "edit"){
        this.delete(row,page);
      }
    });

    this.sqlite.create({
      name: 'salesone_tradeshows.db',
      location: 'default'
    })
    .then(_ => {
      this.getOrderDetails();
    })
    .catch(err => {
      alert("ERR: "+err.message);
    });
  }

  getOrderDetails(){
    var orderId = this.orderData.order_id;
    this.sqlService.getOrderDetails(orderId)
    .then(data => {
      if(data.rows.length > 0){
        this.hasOrder = true;
        for( var i=0; i < data.rows.length; i++){
          this.rowNumber++;
          let qty = data.rows.item(i).qty;
          let subtotal = qty * data.rows.item(i).price;

          this.defaultDiscount = data.rows.item(i).default_discount;

          let discount: any = data.rows.item(i).price * (this.defaultDiscount / 100);
          subtotal = subtotal - (discount.toFixed(2) * qty);
          this.product[this.index] = [];
          this.product[this.index]['rec_id'] = data.rows.item(i).rec_id;
          this.product[this.index]['position'] = data.rows.item(i).position;
          this.product[this.index]['sku'] = data.rows.item(i).sku;
          this.product[this.index]['qty'] = qty;
          this.product[this.index]['qty_available'] = data.rows.item(i).qty_available;
          this.totQty += parseInt(qty);
          this.product[this.index]['price'] = data.rows.item(i).price;
          this.product[this.index]['subtotal'] = subtotal.toFixed(2);
          this.product[this.index]['discounted'] = data.rows.item(i).price - discount.toFixed(2);
          this.grand_total += parseFloat(this.product[this.index]['subtotal']);
          this.totDiscount += discount.toFixed(2) * qty;

          //set customer info
          this.customer_info = [
            data.rows.item(i).contact_name,data.rows.item(i).company_name,data.rows.item(i).company_phone,data.rows.item(i).customer_email,
            data.rows.item(i).customer_shipping,data.rows.item(i).customer_billing,data.rows.item(i).order_notes
          ];

          this.index++;
        }
      }
      else{
        alert("Order details not found.");
      }
    })
    .catch(err => {
        console.log("Error loading order details: " + err.message);
        this.sqlService.logError(err.message);
    });
  }

  openCustomerContact(){
    this.navCtrl.push(CustomerInfoPage,{
      info: this.customer_info
    });
  }

  updateOrder(orderId){
    if(this.customer_info.length < 1){
      alert("Please enter customer information.");
    }
    else{
      //update customer order
      let data = {
        customer: this.customer_info,
        tot_discount : this.totDiscount,
        tot_qty : this.totQty,
        order_total : this.grand_total,
        default_disc: this.defaultDiscount,
        product: this.product,
        order_id: orderId,
        customer_id: this.orderData.customer_id,
        index: this.index
      };

      this.sqlService.updateOrder(data)
      .then(res => {
          alert("Thank you for shopping with us!");
          this.product = [];
          this.rowNumber = 0;
          this.index = 0;
          this.grand_total = 0;
          this.totDiscount = 0;
          this.hasOrder = false;
          this.totQty = 0;
          location.reload();
      })
      .catch(err => {
        console.log("Error updating customer_info: " + err.message);
        this.sqlService.logError(err.message);
      });
    }
  }

  edit(row,qty,page){
    if(page == "edit"){
      let currQty = this.product[row-1]['qty'];

      if(currQty <= qty){
        this.totQty += qty - currQty;
      }
      else{
        this.totQty -= currQty - qty;
      }
      this.product[row-1]['qty'] = qty;

      let iPrice = this.product[row-1]['price'];
      let discount: any = iPrice * (this.defaultDiscount / 100);
      let discountedAmount = iPrice - discount.toFixed(2);

      let currSub = this.product[row-1]['subtotal'];
      let subtotal = discountedAmount * this.product[row-1]['qty'];

      this.product[row-1]['subtotal'] = subtotal.toFixed(2);

      if(currSub <= subtotal){
        this.grand_total += subtotal - currSub;
        this.totDiscount += discount.toFixed(2) * (qty - currQty);
        //this.totDiscount = this.totDiscount.toFixed(2);
      }
      else{
        this.grand_total -= currSub - subtotal;
        this.totDiscount -= discount.toFixed(2) * (currQty - qty);
        //this.totDiscount = this.totDiscount.toFixed(2);
      }
    }
  }
  delete(row,page){
    if(page == "edit"){
      this.totQty -= this.product[row-1]['qty'];
      this.grand_total -= this.product[row-1]['subtotal'];

      let iPrice = this.product[row-1]['price'];
      let discount: any = iPrice * (this.defaultDiscount / 100);

      this.totDiscount = this.totDiscount.toFixed(2);
      this.totDiscount -= discount.toFixed(2) * this.product[row-1]['qty'];

      this.rowNumber--;
      if(this.rowNumber == 0){
        this.hasOrder = false;
      }
      this.index--;

      if ((row-1) !== -1) {
         this.product.splice((row-1), 1);
      }
    }
  }

  scanItem(alwaysShow){
      this.barcodeScanner.scan()
      .then((barcodeData) => {
          this.sqlService.scanItem(barcodeData.text)
          .then(data => {
              let d: any = [];
              d[0] = data.rows.item(0);
              if(data.rows.length){
                  let qty: any;
                  qty = parseInt(prompt("Enter qty: ",'1'));
                  qty = isNaN(qty) ? 1 : qty;
                  this.setItem(qty,d);
              }
              else{
                alert("Item not found! Barcode is: " + barcodeData.text);
              }
          })
          .catch(err => {
              alert("ERR: " + err);
          });
      });
  }

  searchItemByItemCode(itemCode)
  {
      this.sqlService.searchItemByItemCode(itemCode.value)
      .then(data => {
          let d: any = [];
          d[0] = data.rows.item(0);
          if(data.rows.length){
              let qty: any;
              qty = parseInt(prompt("Enter qty: ",'1'));
              qty = isNaN(qty) ? 1 : qty;
              this.setItem(qty,d);
          }
          else{
            alert("Item not found!");
          }
      })
      .catch(err => {
          alert("ERR: " + err);
      });
  }

  setItem(qty,data){
    this.rowNumber++;
    this.hasOrder = true;
    let subtotal = qty * data[0].price;
    let discount: any = data[0].price * (this.defaultDiscount / 100);
    subtotal = subtotal - (discount.toFixed(2) * qty);
    this.product[this.index] = [];
    this.product[this.index]['sku'] = data[0].sku;
    this.product[this.index]['qty'] = qty;
    this.product[this.index]['position'] = this.product[this.index-1]['position'] + 1;
    this.product[this.index]['qty_available'] = data[0].qty_available;
    this.totQty += qty;
    this.product[this.index]['price'] = data[0].price;
    this.product[this.index]['subtotal'] = subtotal.toFixed(2);
    this.product[this.index]['discounted'] = data[0].price - discount.toFixed(2);
    this.grand_total += parseFloat(this.product[this.index]['subtotal']);
    this.totDiscount += discount.toFixed(2) * qty;

    this.index++;
    return;
  }

  applyDefaultDiscount(discountField,e){
    if(e.checked){
      this.defaultDiscount = parseFloat(discountField.value);
      this.discountedOrder = true;
    }
    else{
      this.defaultDiscount = 0;
      discountField.value = 0;
      this.discountedOrder = false;
    }

    this.grand_total = 0;
    this.totDiscount = 0;
    for(var i in this.product){
      let subTotal = this.product[i]['subtotal'];
      let iPrice = this.product[i]['price'];
      let discount: any = iPrice * (this.defaultDiscount / 100);
      let discountedAmount = iPrice - discount.toFixed(2);
      subTotal = discountedAmount * this.product[i]['qty'];

      this.product[i]['subtotal'] = subTotal.toFixed(2);
      this.product[i]['discounted'] = discountedAmount;
      this.grand_total += parseFloat(this.product[i]['subtotal']);
      this.totDiscount += discount.toFixed(2) * this.product[i]['qty'];
    }
  }

  presentPopover(myEvent, rowNumber) {
    let popover = this.popoverCtrl.create(PopoverPage,
      {
        row : rowNumber,
        page: "edit"
      }
    );
    popover.present({
      ev: myEvent,
    });
  }

  cancelOrder(){
    if(confirm("Cancel order?")){
      //cancel order
    }
  }

  doRefresh(refresher) {setTimeout(() => {
      refresher.complete();
    }, 1500);
  }
}
