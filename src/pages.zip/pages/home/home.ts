import { Component  } from '@angular/core';
import { NavController, PopoverController, Events, AlertController  } from 'ionic-angular';
import { Network } from '@ionic-native/network';
import { BarcodeScanner } from '@ionic-native/barcode-scanner';
import { PopoverPage } from '../popover/popover';
import { CustomerInfoPage } from '../customerinfo/customerinfo';
import { SQLite } from '@ionic-native/sqlite';
import { SqliteService } from '../../providers/sqlite-service';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html',
  providers: [SqliteService]
})
export class HomePage {
  private orderData: any;
  public product = [];
  public rowNumber = 0;
  private index = 0;
  private grand_total = 0;
  private totDiscount: any = 0;
  private hasOrder = false;
  private totQty = 0;
  private defaultDiscount = 0;
  private discountedOrder = false;
  private customer_info = [];
  private title = "";
  private save;

  constructor(public navCtrl: NavController, private barcodeScanner: BarcodeScanner, public popoverCtrl: PopoverController, private events: Events, private network: Network, private alertCtrl: AlertController, private sqlite: SQLite, private sqlService: SqliteService ) {
    this.orderData = [];
    this.title = "Order Taking";
    this.save = true;

    this.events.subscribe('row:edited', (row,qty,page)  => {
      if(page == "home"){
        this.edit(row,qty,page);
      }
    });

    this.events.subscribe('row:deleted', (row,page)  => {
      if(page == "home"){
        this.delete(row,page);
      }
    });

    //set customer info
    this.events.subscribe('info:inputted', (info)  => {
      this.customer_info = info;
    });

    this.sqlite.create({
      name: 'salesone_tradeshows.db',
      location: 'default'
    })
  }

  doRefresh(refresher) {setTimeout(() => {
      location.reload();
    }, 500);
  }

  presentPopover(myEvent, rowNumber) {
    let popover = this.popoverCtrl.create(PopoverPage,
      {
        row : rowNumber,
        page: "home"
      }
    );
    popover.present({
      ev: myEvent,
    });
  }

  cancelOrder(){
    if(confirm("Cancel order?")){
      this.clear();
    }
  }

  clear(){
    this.product = [];
    this.rowNumber = 0;
    this.index = 0;
    this.grand_total = 0;
    this.totDiscount = 0;
    this.hasOrder = false;
    this.totQty = 0;
    this.defaultDiscount = 0;
    this.discountedOrder = false;
  }

  finishOrder(){
    if(this.customer_info.length < 1){
      alert("Please enter customer information.");
    }
    else{
      let data = {
        customer: this.customer_info,
        tot_discount : this.totDiscount,
        tot_qty : this.totQty,
        order_total : this.grand_total,
        default_disc: this.defaultDiscount,
        product: this.product,
        index: this.index
      };

      this.sqlService.finishOrder(data)
      .then(res => {
          alert("Thank you for shopping with us!");
          this.product = [];
          this.rowNumber = 0;
          this.index = 0;
          this.grand_total = 0;
          this.totDiscount = 0;
          this.hasOrder = false;
          this.totQty = 0;
          location.reload();
      }).
      catch(err => {
        this.sqlService.logError(err.message);
      });
    }
  }

  scanItem(alwaysShow){
      this.barcodeScanner.scan()
      .then((barcodeData) => {
          this.sqlService.scanItem(barcodeData.text)
          .then(data => {
              let d: any = [];
              d[0] = data.rows.item(0);
              if(data.rows.length){
                  let qty: any;
                  qty = parseInt(prompt("Enter qty: ",'1'));
                  qty = isNaN(qty) ? 1 : qty;
                  this.setItem(qty,d);
              }
              else{
                alert("Item not found! Barcode is: " + barcodeData.text);
              }
          })
          .catch(err => {
              alert("ERR: " + err);
          });
      });
  }

  setItem(qty,data){
    this.rowNumber++;
    this.hasOrder = true;
    let subtotal = qty * data[0].price;
    let discount: any = data[0].price * (this.defaultDiscount / 100);
    subtotal = subtotal - (discount.toFixed(2) * qty);
    this.product[this.index] = [];
    this.product[this.index]['sku'] = data[0].sku;
    this.product[this.index]['qty'] = qty;
    this.product[this.index]['qty_available'] = data[0].qty_available;
    this.totQty += qty;
    this.product[this.index]['price'] = data[0].price;
    this.product[this.index]['subtotal'] = subtotal.toFixed(2);
    this.product[this.index]['discounted'] = data[0].price - discount.toFixed(2);
    this.grand_total += parseFloat(this.product[this.index]['subtotal']);
    this.totDiscount += discount.toFixed(2) * qty;

    this.index++;
    return;
  }

  searchItemByItemCode(itemCode)
  {
      this.sqlService.searchItemByItemCode(itemCode.value)
      .then(data => {
          let d: any = [];
          d[0] = data.rows.item(0);
          if(data.rows.length){
              let qty: any;
              qty = parseInt(prompt("Enter qty: ",'1'));
              qty = isNaN(qty) ? 1 : qty;
              this.setItem(qty,d);
          }
          else{
            alert("Item not found!");
          }
      })
      .catch(err => {
          alert("ERR: " + err);
      });
  }

  edit(row,qty,page){
    if(page == "home"){
      let currQty = this.product[row-1]['qty'];

      if(currQty <= qty){
        this.totQty += qty - currQty;
      }
      else{
        this.totQty -= currQty - qty;
      }
      this.product[row-1]['qty'] = qty;

      let iPrice = this.product[row-1]['price'];
      let discount: any = iPrice * (this.defaultDiscount / 100);
      let discountedAmount = iPrice - discount.toFixed(2);

      let currSub = this.product[row-1]['subtotal'];
      let subtotal = discountedAmount * this.product[row-1]['qty'];

      this.product[row-1]['subtotal'] = subtotal.toFixed(2);

      if(currSub <= subtotal){
        this.grand_total += subtotal - currSub;
        this.totDiscount += discount.toFixed(2) * (qty - currQty);
        //this.totDiscount = this.totDiscount.toFixed(2);
      }
      else{
        this.grand_total -= currSub - subtotal;
        this.totDiscount -= discount.toFixed(2) * (currQty - qty);
      //  this.totDiscount = this.totDiscount.toFixed(2);
      }
    }
  }
  delete(row,page){
    if(page == "home"){
      console.log(this.product);
      this.totQty -= this.product[row-1]['qty'];
      this.grand_total -= this.product[row-1]['subtotal'];

      let iPrice = this.product[row-1]['price'];
      let discount: any = iPrice * (this.defaultDiscount / 100);

      this.totDiscount = this.totDiscount.toFixed(2);
      this.totDiscount -= discount.toFixed(2) * this.product[row-1]['qty'];

      this.rowNumber--;
      if(this.rowNumber == 0){
        this.hasOrder = false;
      }
      this.index--;

      if ((row-1) != -1) {
         this.product.splice((row-1), 1);
      }
    }
  }

  openCustomerContact(){
    this.navCtrl.push(CustomerInfoPage,{
      info: this.customer_info
    });
  }

  applyDefaultDiscount(discountField,e){
    if(e.checked){
      this.defaultDiscount = parseFloat(discountField.value);
      this.discountedOrder = true;
    }
    else{
      this.defaultDiscount = 0;
      discountField.value = 0;
      this.discountedOrder = false;
    }

    this.grand_total = 0;
    this.totDiscount = 0;
    for(var i in this.product){
      let subTotal = this.product[i]['subtotal'];
      let iPrice = this.product[i]['price'];
      let discount: any = iPrice * (this.defaultDiscount / 100);
      let discountedAmount = iPrice - discount.toFixed(2);
      subTotal = discountedAmount * this.product[i]['qty'];

      this.product[i]['subtotal'] = subTotal.toFixed(2);
      this.product[i]['discounted'] = discountedAmount;
      this.grand_total += parseFloat(this.product[i]['subtotal']);
      this.totDiscount += discount.toFixed(2) * this.product[i]['qty'];
    }
  }
}
