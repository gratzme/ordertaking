import { Component } from '@angular/core';
import { NavController, LoadingController, AlertController, Platform } from 'ionic-angular';
import { EditOrderPage } from '../editorder/editorder';
import { File } from '@ionic-native/file';
import { EmailComposer } from '@ionic-native/email-composer';
import { SQLite } from '@ionic-native/sqlite';
import { SqliteService } from '../../providers/sqlite-service';

@Component({
  selector: 'page-list',
  templateUrl: 'list.html',
  providers: [SqliteService]
})
export class ListPage {
  private orders = [];
  private ordersFound = false;

  constructor(private loadingCtrl: LoadingController, private navCtrl: NavController, private alertCtrl: AlertController, private file: File, private platform: Platform, private email: EmailComposer, private sqlite: SQLite, private sqlService: SqliteService) {
    this.sqlite.create({
      name: 'salesone_tradeshows.db',
      location: 'default'
    })
    .then(_ => {
      //get Orders
      this.getList();
    })
    .catch(err => {
      alert("ERR: " + err.message);
    });
  }

  doRefresh(refresher) {setTimeout(() => {
      refresher.complete();
    }, 1500);
  }

  getList(){
    let loader = this.loadingCtrl.create({
      content: "Please wait...",
      duration: 3000
    });
    loader.present();

    this.sqlService.getList()
    .then(data => {
      if(data.rows.length > 0){
        this.ordersFound = true;

        for( var i=0; i < data.rows.length; i++){
          this.orders[i] = [];
          this.orders[i]['order_id'] = data.rows.item(i).order_id;
          this.orders[i]['customer_id'] = data.rows.item(i).customer_id;
          this.orders[i]['date_created'] = data.rows.item(i).date_created;
          this.orders[i]['contact_name'] = data.rows.item(i).contact_name;
        }
      }
      else{
        let alert = this.alertCtrl.create({
          title: 'Order List',
          subTitle: 'No orders found.',
          buttons: ['Dismiss']
        });
        alert.present();
      }

      loader.dismiss();
    })
    .catch(err => {
      this.sqlService.logError(err.message);
    });
  }

  editOrder(order){
    this.navCtrl.push(EditOrderPage,{
      order_data: order
    });
  }

  export(){
    let loader = this.loadingCtrl.create({
      content: "Please wait...",
      duration: 3000
    });
    loader.present();

    this.sqlService.export()
    .subscribe(data => {
      if(this.platform.is('android')){
        var dir = this.file.externalRootDirectory;
      }
      else if(this.platform.is('ios')){
        var dir = this.file.documentsDirectory;
      }

      //create dir ordertaking-export
      this.file.createDir(dir,"ordertaking-export",true)
      .then(_ => {
          var today = new Date();
          var year = today.getFullYear().toString();
          var month = today.getMonth().toString();
          var day = today.getDate().toString();
          var hr = today.getHours().toString();
          var min = today.getMinutes().toString();
          var sec = today.getSeconds().toString();
          var dtime = year + month + month + day + hr + min + sec;
          var fileName = 'export-'+dtime+'.csv';
          this.file.writeFile(dir + "ordertaking-export", fileName, data, true)
          .then(_ => {
              alert('File exported.');
              loader.dismiss();
          })
          .catch(err => {
            this.sqlService.logError(err.message);
            loader.dismiss();
          });
      })
      .catch(err => {
          this.sqlService.logError(err.message);
          loader.dismiss();
      });
    });
  }
}
